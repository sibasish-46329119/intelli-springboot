package com.spring.productcategory.service;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.productcategory.entities.Category;
import com.spring.productcategory.entities.Product;
import com.spring.productcategory.entities.ProductDto;
import com.spring.productcategory.repository.CategoryRepo;
import com.spring.productcategory.repository.ProductRepo;

@Service
public class ProductService {

	@Autowired
	private ProductRepo productRepo;
	
	@Autowired
	private ModelMapper modelMapper;
	
	@Autowired
	private CategoryRepo categoryRepo;
	
	public ProductDto createProduct (ProductDto prodDto, Integer categoryId) throws Exception {
		Category cat = categoryRepo.findById(categoryId).orElseThrow(()-> new Exception("NotFound"));
		
		Product prod = modelMapper.map(prodDto, Product.class);
		prod.setCategory(cat);
		
		Product newProd = productRepo.save(prod);
		return modelMapper.map(newProd, ProductDto.class);
	}
	
	
	public List<ProductDto> getPostByCategory(Integer categoryId)throws Exception{
		
		Category cat = categoryRepo.findById(categoryId).orElseThrow(()-> new Exception("NotFound"));
		List<Product> products = productRepo.findByCategory(cat);
		
		List<ProductDto> allProducts = products.stream().map((product)->modelMapper.map(product,ProductDto.class)).collect(Collectors.toList());
		
		return allProducts;
	}
}
