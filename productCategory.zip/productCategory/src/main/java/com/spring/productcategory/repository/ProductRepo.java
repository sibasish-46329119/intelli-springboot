package com.spring.productcategory.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.spring.productcategory.entities.Category;
import com.spring.productcategory.entities.Product;

public interface ProductRepo extends JpaRepository<Product, Integer>{

	List<Product>findByCategory(Category catgory);
	
}
