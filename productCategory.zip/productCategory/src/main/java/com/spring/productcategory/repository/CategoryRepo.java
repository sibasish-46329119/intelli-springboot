package com.spring.productcategory.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.spring.productcategory.entities.Category;

public interface CategoryRepo extends JpaRepository<Category, Integer>{

}
