package com.spring.productcategory.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.spring.productcategory.entities.Category;
import com.spring.productcategory.service.CategoryService;

@RestController
@RequestMapping("/category")
public class CategoryController {

	@Autowired
	private CategoryService categoryService;
	
	@PostMapping("/addCategory")
	public Category addCategory(@RequestBody Category category) {
		Category addCategory = categoryService.createCategory(category);
		return addCategory;
	}
	
	@GetMapping("/allCategory")
	public List<Category> getAllCategory(){
		List<Category> categories = categoryService.getAllCategory();
		return categories;
	}
	
}
