package com.spring.productcategory.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.spring.productcategory.entities.ProductDto;
import com.spring.productcategory.service.ProductService;

@RestController
@RequestMapping("/product")
public class ProductController {

	@Autowired
	private ProductService productService;
	
	@PostMapping("/addProduct/{categoryId}")
	public ProductDto addProduct(@RequestBody ProductDto prod, @PathVariable Integer categoryId) throws Exception {
		ProductDto addProduct = productService.createProduct(prod, categoryId);
		return addProduct;
	}
	
	@GetMapping("/getProduct/{categoryId}")
	public List<ProductDto> getProduct(@PathVariable Integer categoryId) throws Exception {
		List<ProductDto> getProd = productService.getPostByCategory(categoryId);
		return getProd;
	}
}
