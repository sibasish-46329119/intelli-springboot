package com.spring.librarymanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibraryInventoryManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
