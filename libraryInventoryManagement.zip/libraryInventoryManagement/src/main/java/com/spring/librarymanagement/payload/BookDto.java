package com.spring.librarymanagement.payload;

import java.util.HashSet;
import java.util.Set;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@Getter
@Setter
public class BookDto {

	private Long bookId;
	private String bookTitle;
	private String bookAuthor;
	private Long isbn;
	private Set<AuthorDto> author = new HashSet<>();
}
