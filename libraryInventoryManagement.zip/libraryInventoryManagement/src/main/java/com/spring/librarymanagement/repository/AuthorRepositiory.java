package com.spring.librarymanagement.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.spring.librarymanagement.entity.Author;

public interface AuthorRepositiory extends JpaRepository<Author, Long>{
	
}
