package com.spring.librarymanagement.payload;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@NoArgsConstructor
@Setter
public class AuthorDto {

	private Long authorId;
	private String authorName;
}
