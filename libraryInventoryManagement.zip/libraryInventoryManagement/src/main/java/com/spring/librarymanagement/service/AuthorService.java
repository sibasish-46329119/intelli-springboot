package com.spring.librarymanagement.service;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.librarymanagement.entity.Author;
import com.spring.librarymanagement.entity.Book;
import com.spring.librarymanagement.payload.AuthorDto;
import com.spring.librarymanagement.repository.AuthorRepositiory;
import com.spring.librarymanagement.repository.BookRepository;

@Service
public class AuthorService {

	@Autowired
	private ModelMapper modelMapper;
	
	@Autowired
	private AuthorRepositiory authorRepository;

	@Autowired
	private BookRepository bookRepository;
	
	public AuthorDto authorCreate (AuthorDto authorDto, Long bookId) throws Exception {
		Book book = bookRepository.findById(bookId).orElseThrow(() -> new Exception("Not Found"));
		Author auth = this.modelMapper.map(authorDto, Author.class);
		auth.setBook(book);
		Author newAuthor = authorRepository.save(auth);
		
		return this.modelMapper.map(newAuthor, AuthorDto.class);
		
	}
}
