package com.spring.librarymanagement.service;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.librarymanagement.entity.Book;
import com.spring.librarymanagement.payload.BookDto;
import com.spring.librarymanagement.repository.BookRepository;

@Service
public class BookService {

	@Autowired
	private BookRepository bookRepository;
	
	@Autowired
	private ModelMapper modelMapper;
	
	public BookDto addBook(BookDto bookDto) {
		Book newBook = this.modelMapper.map(bookDto, Book.class);
		Book book = this.bookRepository.save(newBook);
		return this.modelMapper.map(book, BookDto.class);
	}

	public BookDto updateBook(BookDto bookdto, Long bookId) throws Exception {
		Book uBook = this.bookRepository.findById(bookId).orElseThrow(()-> new Exception("NotFound"));
		uBook.setBookTitle(bookdto.getBookTitle());
		uBook.setBookAuthor(bookdto.getBookAuthor());
		uBook.setIsbn(bookdto.getIsbn());
		
		Book updatedBooks = bookRepository.save(uBook);
		
		return this.modelMapper.map(updatedBooks, BookDto.class);
	}
	
	public List<BookDto> getAllBooks(){
		List<Book> books = this.bookRepository.findAll();
		List<BookDto> bookDtos = books.stream().map((book)->this.modelMapper.map(book, BookDto.class)).collect(Collectors.toList());
		return bookDtos;
	}
	
	public BookDto bookById(Long bookId) throws Exception {
		Book book = bookRepository.findById(bookId).orElseThrow(()-> new Exception("NotFound"));
		return this.modelMapper.map(book, BookDto.class);
	}
	
	public void deleteBook(Long bookId) throws Exception{
		Book book = bookRepository.findById(bookId).orElseThrow(()-> new Exception("NotFound"));
		bookRepository.delete(book);
	}
}
