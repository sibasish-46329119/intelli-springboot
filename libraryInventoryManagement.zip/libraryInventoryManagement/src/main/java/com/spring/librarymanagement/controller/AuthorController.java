package com.spring.librarymanagement.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.spring.librarymanagement.payload.AuthorDto;
import com.spring.librarymanagement.service.AuthorService;

@RestController
@RequestMapping("/author")
public class AuthorController {

	@Autowired
	private AuthorService authorService;
	
	@PostMapping("/createAuth/bookId/{bookId}")
	public AuthorDto authorCreate(@RequestBody AuthorDto author, @PathVariable Long bookId) throws Exception {
		AuthorDto auth = authorService.authorCreate(author, bookId);
		return auth;
	}
	
}
