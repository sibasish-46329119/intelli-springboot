package com.spring.librarymanagement.entity;

import java.util.HashSet;
import java.util.Set;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@NoArgsConstructor
@Getter
@Setter
@Table(name="books")
public class Book {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long bookId;

	@Column(name = "title", length = 100, nullable = false)
	private String bookTitle;

	@Column(name = "author", length = 100, nullable = false)
	private String bookAuthor;

	@Column(name = "isbn")
	private Long isbn;

	@OneToMany(mappedBy = "book", cascade = CascadeType.ALL)
	private Set<Author> author = new HashSet<>();
}
