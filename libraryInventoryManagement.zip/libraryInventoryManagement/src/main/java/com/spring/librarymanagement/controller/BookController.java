package com.spring.librarymanagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.spring.librarymanagement.entity.Book;
import com.spring.librarymanagement.payload.BookDto;
import com.spring.librarymanagement.service.BookService;

@RestController
@RequestMapping("/book")
public class BookController {

	@Autowired
	private BookService bookService;
	
	@PostMapping("/addBook")
	public BookDto addBook (@RequestBody BookDto book) {
		BookDto addBook = bookService.addBook(book);
		return addBook;
	}
	
	@PutMapping("/updateBook/{bookId}")
	public BookDto updateBook(@RequestBody BookDto book, @PathVariable Long bookId) throws Exception {
		BookDto uBook = bookService.updateBook(book, bookId);
		return uBook;
	}
	
	@GetMapping("/allBooks")
	public List<BookDto> getAllBooks(){
		List<BookDto> books = bookService.getAllBooks();
		return books;
	}
	
	@GetMapping("/bookById/{bookId}")
	public BookDto getBooksById(@PathVariable Long bookId) throws Exception{
		BookDto books = bookService.bookById(bookId);
		return books;
	}
	
	@DeleteMapping("/deleteBook/{bookId}")
	public void deleteBookById(@PathVariable Long bookId) throws Exception {
		bookService.deleteBook(bookId);
	}
}
